# Curso de Bases de datos con PostgreSQL

## Pasos para levantar el proyecto

1. Tener docker Desktop o el demonio de Docker corriendo
2. Clonar el proyecto
3. Navegar a la carpeta del proyecto
4. Ejecutar ```docker compose up -d```
5. Revisar el **archivo docker-compose.yml** para los usuarios y contraseñas


