
CREATE TABLE usersDual (
	id1 int,
	id2 int,
	PRIMARY KEY (id1, id2)
);