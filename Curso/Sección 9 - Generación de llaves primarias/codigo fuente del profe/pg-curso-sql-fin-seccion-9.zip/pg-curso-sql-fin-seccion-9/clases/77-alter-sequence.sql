


ALTER SEQUENCE continent_code_seq
	RESTART WITH 8;

  